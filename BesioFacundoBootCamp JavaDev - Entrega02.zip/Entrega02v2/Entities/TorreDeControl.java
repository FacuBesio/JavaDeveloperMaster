package Bootcamp62705.BesioF.Entrega02v2.Entities;

import Bootcamp62705.BesioF.Entrega02v2.Interfaces.Aterrizable;

public class TorreDeControl {

    /*Solo aquellos Voladores que cumplan e implementen la Interfaz Aterrizable podran ejecutar el metodo 'PermisoAterrizar()'.*/
	/*
	public static void PermisoAterrizar(Aterrizable volador) {
		
		volador.aterrizar();
		
		if( volador instanceof Avion ){
	        Avion avion = (Avion)volador;
	        System.out.println("PERMISO DE ATERRIZAR AVION EN AEROPUETO OTORGADO - " +avion.getNombre());
        }
		
		if( volador instanceof Helicoptero ){
			Helicoptero helicoptero = (Helicoptero)volador;
	        System.out.println("PERMISO DE ATERRIZAR HELICOPTERO EN AEROPUETO OTORGADO - " +helicoptero.getNombre());
        }
		
	};

	 */
    public TorreDeControl() {

    }
    public String PermisoAterrizar(Volador v) {
        String mensaje = v.getNombre() + "\t- Estado de autorización -\t";
        if (v instanceof Aterrizable) {
            mensaje += v.getNombre() + " -> Autorizado: ";
            mensaje += "\t" + ((Aterrizable) v).aterrizar();
        } else {
            mensaje += v.getNombre() + " -> ** NO Autorizado **";
        }
        return mensaje;
    }

}
