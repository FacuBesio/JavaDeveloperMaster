package Bootcamp62705.BesioF.Entrega02v2.Interfaces;

public interface Aterrizable {
	
	//void aterrizar();
	String aterrizar();
}
