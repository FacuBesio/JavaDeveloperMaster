package Bootcamp62705.BesioF.Entrega02v2.Main;

import Bootcamp62705.BesioF.Entrega02v2.Entities.*;

import java.util.ArrayList;
import java.util.List;

public class Test_Aeropuerto {

    public static void main(String[] args) {

        System.out.println("********** AEROPUERTO **********");

        TorreDeControl torre = new TorreDeControl();/* agregado leandro */

        System.out.println("---- volador1 ----");
        Avion volador1 = new Avion("Avion1", 900, "Aerol�neas Argentinas", "Boeing 747", 400, 350);
        System.out.println(volador1);

        //TorreDeControl.PermisoAterrizar(volador1);
        System.out.println(torre.PermisoAterrizar(volador1));

        System.out.println("");
        System.out.println("---- volador2 ----");
        Helicoptero volador2 = new Helicoptero("Helicoptero1", 200, "Blanco y Celeste", "Bell", "204/205", "Rescate");
        System.out.println(volador2);

        //TorreDeControl.PermisoAterrizar(volador2);
        System.out.println(torre.PermisoAterrizar(volador2));

        System.out.println("");
        System.out.println("---- volador3 ----");
        Superman volador3 = new Superman("Clark Kent", 2000000, true, "roja");
        System.out.println(volador3);
        
        /* TorreDeControl.PermisoAterrizar(volador3); => No puede obtener permiso de Aterrizar en el Aeropuerto 
         desde la Torre de Control porque no cumple con la Interfaz Aterrizable, pero si tiene la capacidad de aterrizar
         fuera del Aeropuerto.*/

        // AGREGADO
        // fijate que si se puede llamar al metodo y que retorne que no tiene permisos, con la implementación que hice
        // ya que es el método quien toma al volador y evalua si puede o no, en dependiendo de que sea aterrizable
        System.out.println(torre.PermisoAterrizar(volador3));

        volador3.aterrizar_superman();

        System.out.println("");
        System.out.println("---- volador4 ----");
        Ovni volador4 = new Ovni("Ovni1", 8000, "Nave Espacial 01", "Gris");
        System.out.println(volador4);
        
        /* TorreDeControl.PermisoAterrizar(volador4); => No puede obtener permiso de Aterrizar en el Aeropuerto 
        desde la Torre de Control porque no cumple con la Interfaz Aterrizable, pero si tiene la capacidad de aterrizar
        fuera del Aeropuerto.*/

        //idem volador3
        System.out.println(torre.PermisoAterrizar(volador4));

        volador4.aterrizar_ovni();

///////////////////////////////////////////////////////////////

        System.out.println("la idea es que puedas tener un método al cual llamar siempre");
        String separador = "-----------------------------------------------------------------------------------------";
        List<Volador> voladores = new ArrayList<Volador>();
        voladores.add(volador1);
        voladores.add(volador2);
        voladores.add(volador3);
        voladores.add(volador4);

        for (Volador v: voladores) {
            System.out.print("\n"+separador);
            System.out.println("\n" + v.toString());
            System.out.print(torre.PermisoAterrizar(v));
            System.out.println("\n"+separador);

        }

    }

}
